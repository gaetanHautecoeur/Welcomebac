<?php

namespace TestFixtures;

use Doctrine\Common\DataFixtures\FixtureInterface;

class MyFixture1 implements FixtureInterface
{
    public function load($manager)
    {
    }
}