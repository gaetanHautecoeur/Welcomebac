<?php

namespace TestFixtures;

use Doctrine\Common\DataFixtures\FixtureInterface;

class MyFixture2 implements FixtureInterface
{
    public function load($manager)
    {
    }
}